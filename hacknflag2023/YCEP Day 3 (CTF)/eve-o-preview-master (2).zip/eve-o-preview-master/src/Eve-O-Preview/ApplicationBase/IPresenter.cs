﻿namespace EveOPreview
{
	public interface IPresenter
	{
		void Run();
	}
}