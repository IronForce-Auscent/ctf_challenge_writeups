namespace EveOPreview.View
{
	public enum ViewZoomAnchor
	{
		NW,
		N,
		NE,
		W,
		C,
		E,
		SW,
		S,
		SE
	}
}