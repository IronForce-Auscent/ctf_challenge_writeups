﻿using MediatR;

namespace EveOPreview.Mediator.Messages
{
	sealed class StartService : IRequest
	{
	}
}