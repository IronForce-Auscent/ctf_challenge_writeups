﻿using MediatR;

namespace EveOPreview.Mediator.Messages
{
	sealed class ThumbnailFrameSettingsUpdated : INotification
	{
	}
}