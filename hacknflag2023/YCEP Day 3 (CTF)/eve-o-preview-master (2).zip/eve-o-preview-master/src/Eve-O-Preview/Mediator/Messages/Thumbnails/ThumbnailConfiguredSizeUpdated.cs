﻿using MediatR;

namespace EveOPreview.Mediator.Messages
{
	sealed class ThumbnailConfiguredSizeUpdated : INotification
	{
	}
}