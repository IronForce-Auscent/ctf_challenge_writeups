﻿namespace EveOPreview.Configuration
{
	public enum ZoomAnchor
	{
		NW,
		N,
		NE,
		W,
		C,
		E,
		SW,
		S,
		SE
	}
}