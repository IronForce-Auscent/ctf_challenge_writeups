﻿namespace EveOPreview.Services.Interop
{
	static class DWM_TNP_CONSTANTS
	{
		public const uint DWM_TNP_RECTDESTINATION = 0x00000001;
		public const uint DWM_TNP_RECTSOURCE = 0x00000002;
		public const uint DWM_TNP_OPACITY = 0x00000004;
		public const uint DWM_TNP_VISIBLE = 0x00000008;
		public const uint DWM_TNP_SOURCECLIENTAREAONLY = 0x00000010;
	}
}