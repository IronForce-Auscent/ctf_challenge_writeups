﻿using System.Windows;

namespace EveOMock
{
	public partial class App : Application
	{
	}
}
